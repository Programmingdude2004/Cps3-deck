// CP3 container: single-file CPS3 ROM image (BIOS + program + graphics + keys).
#ifndef CP3_H
#define CP3_H
#include "burnint.h"
#ifdef __cplusplus
extern "C++" {
#endif
// Parse header of a .cp3 file. Returns 0 on success.
INT32 Cp3Open(const char *path);
void  Cp3Close();
INT32 Cp3Active();
const char *Cp3DriverName();
UINT32 Cp3Key1();
UINT32 Cp3Key2();
// Read a named region ("BIOS", "PRGENC", "GFX") into dest (up to maxlen bytes). Returns 0 if the region exists and was read.
INT32 Cp3ReadRegion(const char *region, UINT8 *dest, UINT32 maxlen, UINT32 *got);
#ifdef __cplusplus
}
#endif
#endif
