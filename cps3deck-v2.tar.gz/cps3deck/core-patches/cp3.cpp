// CP3 container reader.
// Layout (little endian):
//   0x00 "CP3P"  0x04 u32 version(1)  0x08 u32 key1  0x0c u32 key2  0x10 u32 region_count
//   0x14 char name[16] (driver name)  0x24 char desc[64]
//   0x64 region table: {char name[8]; u32 offset; u32 size} * region_count
// Regions: BIOS (decrypted, LE words), PRGENC (program in RomGame layout, encrypted),
//          PRGDEC (optional; derivable from PRGENC + keys, ignored by the loader), GFX (character data).
#include "cp3.h"
#include <stdio.h>
#include <string.h>
#include <string>

struct Cp3Region { char name[9]; UINT32 off, size; };
static std::string cp3_path;
static bool cp3_active = false;
static char cp3_name[17];
static UINT32 cp3_k1, cp3_k2;
static Cp3Region cp3_regions[16];
static UINT32 cp3_count;

static UINT32 rd32(const UINT8 *p) { return p[0] | (p[1] << 8) | (p[2] << 16) | ((UINT32)p[3] << 24); }

INT32 Cp3Open(const char *path)
{
	Cp3Close();
	FILE *f = fopen(path, "rb");
	if (!f) return 1;
	UINT8 h[0x64];
	if (fread(h, 1, sizeof(h), f) != sizeof(h) || memcmp(h, "CP3P", 4) != 0 || rd32(h + 4) != 1) { fclose(f); return 2; }
	cp3_k1 = rd32(h + 8); cp3_k2 = rd32(h + 12);
	cp3_count = rd32(h + 16);
	if (cp3_count == 0 || cp3_count > 16) { fclose(f); return 3; }
	memcpy(cp3_name, h + 20, 16); cp3_name[16] = 0;
	for (UINT32 i = 0; i < cp3_count; i++) {
		UINT8 e[16];
		if (fread(e, 1, 16, f) != 16) { fclose(f); return 4; }
		memcpy(cp3_regions[i].name, e, 8); cp3_regions[i].name[8] = 0;
		cp3_regions[i].off = rd32(e + 8); cp3_regions[i].size = rd32(e + 12);
	}
	fclose(f);
	cp3_path = path; cp3_active = true;
	return 0;
}

void Cp3Close() { cp3_active = false; cp3_path.clear(); cp3_count = 0; }
INT32 Cp3Active() { return cp3_active; }
const char *Cp3DriverName() { return cp3_name; }
UINT32 Cp3Key1() { return cp3_k1; }
UINT32 Cp3Key2() { return cp3_k2; }

INT32 Cp3ReadRegion(const char *region, UINT8 *dest, UINT32 maxlen, UINT32 *got)
{
	if (!cp3_active) return 1;
	for (UINT32 i = 0; i < cp3_count; i++) {
		if (strncmp(cp3_regions[i].name, region, 8) != 0) continue;
		FILE *f = fopen(cp3_path.c_str(), "rb");
		if (!f) return 2;
		UINT32 n = cp3_regions[i].size < maxlen ? cp3_regions[i].size : maxlen;
		fseek(f, cp3_regions[i].off, SEEK_SET);
		UINT32 r = (UINT32)fread(dest, 1, n, f);
		fclose(f);
		if (got) *got = r;
		return r == n ? 0 : 3;
	}
	return 4;  // region not present
}
