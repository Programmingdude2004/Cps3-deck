Apply over libretro/fbalpha2012 (svn-current/trunk):
  cp3.cpp, cp3.h, cps3run.cpp -> src/burn/drv/cps3/
  libretro.cpp                -> src/burner/libretro/
  makefile.burn_rules         -> ./
Then: make -f makefile.libretro target=cps3   (see top-level Makefile for the two link stubs)
