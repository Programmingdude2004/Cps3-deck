// Stubs for symbols the CPS3-only target references but does not build.
typedef short INT16; typedef unsigned char UINT8;
INT16 AnalogDeadZone(INT16 v) { return v; }
UINT8 NeoSystem = 0;
