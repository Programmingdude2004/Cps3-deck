# CPS3 Deck v2
OpenGL/SDL2 front end + fbalpha2012 CPS3 core for Steam Deck / SteamOS. Needs OpenGL 3.3 (Deck: fine).

Run: `./cps3deck [game.cp3|game.zip]` (core `fbalpha2012_cps3_libretro.so` next to it, or `--core`).
Games: `.cp3` single-file images or MAME-style CPS3 zips in `~/Roms/cps3`. Config/states: `~/.config/cps3deck/`.

## Menus (Start+Back or Esc in game; SELECT in the browser = Settings)
- Display: scaling, **render resolution** (native/1080p/1440p/4K/8K internal, box-filtered down to the window),
  **anti-aliasing** (off, sharp edge-AA, bicubic, FXAA), **screen model** (none / OLED / plasma) + strength 0-100%.
- Audio: **output rate** 32 / 44.1 / 48 / 96 / 192 kHz (16-tap Blackman windowed-sinc resampler from the core's ~32 kHz).
- Game: **Region** (top of pause menu; resets the game, the BIOS reads it at boot) and all DIP/core options.
- Browser: X = convert the selected zip to a `.cp3` next to it. CLI: `./cps3deck --convert sfiiin.zip`.
- `cp3slim.py` shrinks an old 4-region cp3 (drops the redundant decrypted program).
Controls: X/Y/LB = LP/MP/HP, A/B/RB = LK/MK/HK; remappable in Controls. Keyboard: arrows, A S D / Z X C, Enter, RShift, F11.

## Screen models
OLED: emissive RGB-stripe subpixels with a thin black matrix, true black, mild brightness limiting, no persistence.
Plasma: wider rib/cell grid, per-channel phosphor decay (green longest), faint halation, raised black, strong brightness
limiting, temporal dither that is stronger in the darks. Both work in linear light on a per-source-pixel cell grid.
These are physically motivated models, not measurements of a specific panel. Heavier settings (8K, bicubic) cost GPU time.

Build: `make` (see Makefile; core patches in core-patches/ go over libretro/fbalpha2012).
