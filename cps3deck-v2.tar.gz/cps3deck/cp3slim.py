#!/usr/bin/env python3
"""Shrink a .cp3: drops the PRGDEC region (the decrypted program), which the deck loader
regenerates from PRGENC + the stored keys at load time. Usage: cp3slim.py in.cp3 [out.cp3]"""
import struct, sys
src = sys.argv[1]; dst = sys.argv[2] if len(sys.argv) > 2 else src.rsplit('.', 1)[0] + '.slim.cp3'
d = open(src, 'rb').read()
assert d[:4] == b'CP3P' and struct.unpack_from('<I', d, 4)[0] == 1, 'not a CP3 v1 file'
count = struct.unpack_from('<I', d, 16)[0]
regs = []
for i in range(count):
    name, off, size = struct.unpack_from('<8sII', d, 0x64 + i * 16)
    regs.append((name.rstrip(b'\0').decode(), off, size))
keep = [r for r in regs if r[0] != 'PRGDEC']
assert any(r[0] == 'PRGENC' for r in keep), 'no PRGENC region'
hdr = bytearray(d[:0x800]); struct.pack_into('<I', hdr, 16, len(keep))
for i in range(0x64, 0x800): hdr[i] = 0
out = bytearray(); pos = 0x800
for i, (n, off, size) in enumerate(keep):
    struct.pack_into('<8sII', hdr, 0x64 + i * 16, n.encode(), pos, size)
    out += d[off:off + size]; pos += size
open(dst, 'wb').write(bytes(hdr[:0x800]) + bytes(out))
print(f'{src}: {len(d):,} -> {dst}: {0x800 + len(out):,} bytes (dropped PRGDEC)')
