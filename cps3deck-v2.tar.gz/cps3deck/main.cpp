// cps3deck v2 - OpenGL/SDL2 front end for the fbalpha2012 CPS3 core (Steam Deck / SteamOS)
//  * libretro host: video via GLSL pipeline (internal upscale 1080p..8K, AA modes, OLED / plasma display models)
//  * SDL game controllers, controller-driven menus, button remap, save states
//  * audio output at 32/44.1/48/96/192 kHz through a windowed-sinc resampler
//  * core options (incl. Region) exposed in the menu; .cp3 single-file images; zip -> .cp3 converter
#include <SDL2/SDL.h>
#include <dlfcn.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <libgen.h>
#include <algorithm>
#include <cmath>
#include <cstdarg>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <functional>
#include <map>
#include <string>
#include <vector>
#include "libretro.h"

static std::string home_dir() { const char *h = getenv("HOME"); return h ? h : "."; }
static bool is_dir(const std::string &p) { struct stat st; return stat(p.c_str(), &st) == 0 && S_ISDIR(st.st_mode); }
static long file_size(const std::string &p) { struct stat st; return stat(p.c_str(), &st) == 0 ? (long)st.st_size : -1; }
static void mkdirs(const std::string &p) { for (size_t i = 1; i <= p.size(); i++) if (i == p.size() || p[i] == '/') mkdir(p.substr(0, i).c_str(), 0755); }
static std::string upper(std::string s) { for (auto &c : s) c = (char)toupper((unsigned char)c); return s; }
static std::string base_noext(const std::string &p) {
    size_t s = p.find_last_of('/'); std::string b = s == std::string::npos ? p : p.substr(s + 1);
    size_t d = b.find_last_of('.'); return d == std::string::npos ? b : b.substr(0, d);
}
static bool ends_with_ci(const std::string &s, const char *suf) {
    size_t n = strlen(suf); if (s.size() < n) return false;
    for (size_t i = 0; i < n; i++) if (tolower((unsigned char)s[s.size() - n + i]) != suf[i]) return false;
    return true;
}

// ================================================================= minimal OpenGL loader (3.3 core)
typedef unsigned int GLenum, GLuint, GLbitfield; typedef int GLint, GLsizei; typedef float GLfloat;
typedef unsigned char GLboolean; typedef char GLchar; typedef ptrdiff_t GLsizeiptr;
#define GL_COLOR_BUFFER_BIT 0x4000
#define GL_TRIANGLES 0x0004
#define GL_TEXTURE_2D 0x0DE1
#define GL_UNSIGNED_BYTE 0x1401
#define GL_UNSIGNED_SHORT_5_6_5 0x8363
#define GL_FLOAT 0x1406
#define GL_RGB 0x1907
#define GL_RGBA 0x1908
#define GL_RED 0x1903
#define GL_R8 0x8229
#define GL_RGBA8 0x8058
#define GL_RGBA16F 0x881A
#define GL_BGRA 0x80E1
#define GL_TEXTURE_MIN_FILTER 0x2801
#define GL_TEXTURE_MAG_FILTER 0x2800
#define GL_TEXTURE_WRAP_S 0x2802
#define GL_TEXTURE_WRAP_T 0x2803
#define GL_NEAREST 0x2600
#define GL_LINEAR 0x2601
#define GL_LINEAR_MIPMAP_LINEAR 0x2703
#define GL_CLAMP_TO_EDGE 0x812F
#define GL_UNPACK_ROW_LENGTH 0x0CF2
#define GL_UNPACK_ALIGNMENT 0x0CF5
#define GL_FRAMEBUFFER 0x8D40
#define GL_COLOR_ATTACHMENT0 0x8CE0
#define GL_FRAMEBUFFER_COMPLETE 0x8CD5
#define GL_ARRAY_BUFFER 0x8892
#define GL_STREAM_DRAW 0x88E0
#define GL_VERTEX_SHADER 0x8B31
#define GL_FRAGMENT_SHADER 0x8B30
#define GL_COMPILE_STATUS 0x8B81
#define GL_LINK_STATUS 0x8B82
#define GL_INFO_LOG_LENGTH 0x8B84
#define GL_BLEND 0x0BE2
#define GL_SCISSOR_TEST 0x0C11
#define GL_SRC_ALPHA 0x0302
#define GL_ONE_MINUS_SRC_ALPHA 0x0303
#define GL_TEXTURE0 0x84C0
#define GL_MAX_TEXTURE_SIZE 0x0D33
#define GL_VERSION 0x1F02
#define GL_RENDERER 0x1F01
#define GL_BACK 0x0405
#define GLFUNCS(X) \
    X(void, glClear, (GLbitfield)) X(void, glClearColor, (GLfloat, GLfloat, GLfloat, GLfloat)) \
    X(void, glViewport, (GLint, GLint, GLsizei, GLsizei)) X(void, glScissor, (GLint, GLint, GLsizei, GLsizei)) \
    X(void, glEnable, (GLenum)) X(void, glDisable, (GLenum)) X(void, glBlendFunc, (GLenum, GLenum)) \
    X(void, glGenTextures, (GLsizei, GLuint *)) X(void, glDeleteTextures, (GLsizei, const GLuint *)) X(void, glBindTexture, (GLenum, GLuint)) \
    X(void, glTexImage2D, (GLenum, GLint, GLint, GLsizei, GLsizei, GLint, GLenum, GLenum, const void *)) \
    X(void, glTexSubImage2D, (GLenum, GLint, GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, const void *)) \
    X(void, glTexParameteri, (GLenum, GLenum, GLint)) X(void, glPixelStorei, (GLenum, GLint)) \
    X(void, glActiveTexture, (GLenum)) X(void, glGenerateMipmap, (GLenum)) X(void, glDrawArrays, (GLenum, GLint, GLsizei)) \
    X(void, glReadPixels, (GLint, GLint, GLsizei, GLsizei, GLenum, GLenum, void *)) X(void, glReadBuffer, (GLenum)) \
    X(void, glGetIntegerv, (GLenum, GLint *)) X(const unsigned char *, glGetString, (GLenum)) \
    X(GLuint, glCreateShader, (GLenum)) X(void, glShaderSource, (GLuint, GLsizei, const GLchar *const *, const GLint *)) \
    X(void, glCompileShader, (GLuint)) X(void, glGetShaderiv, (GLuint, GLenum, GLint *)) X(void, glGetShaderInfoLog, (GLuint, GLsizei, GLsizei *, GLchar *)) \
    X(GLuint, glCreateProgram, (void)) X(void, glAttachShader, (GLuint, GLuint)) X(void, glLinkProgram, (GLuint)) \
    X(void, glGetProgramiv, (GLuint, GLenum, GLint *)) X(void, glGetProgramInfoLog, (GLuint, GLsizei, GLsizei *, GLchar *)) \
    X(void, glUseProgram, (GLuint)) X(GLint, glGetUniformLocation, (GLuint, const GLchar *)) \
    X(void, glUniform1i, (GLint, GLint)) X(void, glUniform1f, (GLint, GLfloat)) X(void, glUniform2f, (GLint, GLfloat, GLfloat)) \
    X(void, glUniform3f, (GLint, GLfloat, GLfloat, GLfloat)) \
    X(void, glGenVertexArrays, (GLsizei, GLuint *)) X(void, glBindVertexArray, (GLuint)) \
    X(void, glGenBuffers, (GLsizei, GLuint *)) X(void, glBindBuffer, (GLenum, GLuint)) X(void, glBufferData, (GLenum, GLsizeiptr, const void *, GLenum)) \
    X(void, glEnableVertexAttribArray, (GLuint)) X(void, glVertexAttribPointer, (GLuint, GLint, GLenum, GLboolean, GLsizei, const void *)) \
    X(void, glGenFramebuffers, (GLsizei, GLuint *)) X(void, glBindFramebuffer, (GLenum, GLuint)) X(void, glDeleteFramebuffers, (GLsizei, const GLuint *)) \
    X(void, glFramebufferTexture2D, (GLenum, GLenum, GLenum, GLuint, GLint)) X(GLenum, glCheckFramebufferStatus, (GLenum))
#define X(r, n, a) static r(*n) a;
GLFUNCS(X)
#undef X
static bool load_gl() {
#define X(r, n, a) n = (r(*) a)SDL_GL_GetProcAddress(#n); if (!n) { fprintf(stderr, "missing GL function %s\n", #n); return false; }
    GLFUNCS(X)
#undef X
    return true;
}
// ---------------------------------------------------------------- 5x7 font
static const char *FONT_CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789.,:-_/()+><!?%[]=";
static const unsigned char FONT[][7] = {
    {0x0E,0x11,0x11,0x1F,0x11,0x11,0x11},{0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E},{0x0E,0x11,0x10,0x10,0x10,0x11,0x0E},
    {0x1E,0x11,0x11,0x11,0x11,0x11,0x1E},{0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F},{0x1F,0x10,0x10,0x1E,0x10,0x10,0x10},
    {0x0E,0x11,0x10,0x17,0x11,0x11,0x0F},{0x11,0x11,0x11,0x1F,0x11,0x11,0x11},{0x0E,0x04,0x04,0x04,0x04,0x04,0x0E},
    {0x07,0x02,0x02,0x02,0x02,0x12,0x0C},{0x11,0x12,0x14,0x18,0x14,0x12,0x11},{0x10,0x10,0x10,0x10,0x10,0x10,0x1F},
    {0x11,0x1B,0x15,0x15,0x11,0x11,0x11},{0x11,0x11,0x19,0x15,0x13,0x11,0x11},{0x0E,0x11,0x11,0x11,0x11,0x11,0x0E},
    {0x1E,0x11,0x11,0x1E,0x10,0x10,0x10},{0x0E,0x11,0x11,0x11,0x15,0x12,0x0D},{0x1E,0x11,0x11,0x1E,0x14,0x12,0x11},
    {0x0F,0x10,0x10,0x0E,0x01,0x01,0x1E},{0x1F,0x04,0x04,0x04,0x04,0x04,0x04},{0x11,0x11,0x11,0x11,0x11,0x11,0x0E},
    {0x11,0x11,0x11,0x11,0x11,0x0A,0x04},{0x11,0x11,0x11,0x15,0x15,0x1B,0x11},{0x11,0x11,0x0A,0x04,0x0A,0x11,0x11},
    {0x11,0x11,0x0A,0x04,0x04,0x04,0x04},{0x1F,0x01,0x02,0x04,0x08,0x10,0x1F},
    {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E},{0x04,0x0C,0x04,0x04,0x04,0x04,0x0E},{0x0E,0x11,0x01,0x02,0x04,0x08,0x1F},
    {0x1F,0x02,0x04,0x02,0x01,0x11,0x0E},{0x02,0x06,0x0A,0x12,0x1F,0x02,0x02},{0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E},
    {0x06,0x08,0x10,0x1E,0x11,0x11,0x0E},{0x1F,0x01,0x02,0x04,0x08,0x08,0x08},{0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E},
    {0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C},
    {0,0,0,0,0,0x0C,0x0C},{0,0,0,0,0x0C,0x04,0x08},{0,0x0C,0x0C,0,0x0C,0x0C,0},{0,0,0,0x1F,0,0,0},{0,0,0,0,0,0,0x1F},
    {0x01,0x02,0x02,0x04,0x08,0x08,0x10},{0x02,0x04,0x08,0x08,0x08,0x04,0x02},{0x08,0x04,0x02,0x02,0x02,0x04,0x08},
    {0,0x04,0x04,0x1F,0x04,0x04,0},{0x08,0x04,0x02,0x01,0x02,0x04,0x08},{0x02,0x04,0x08,0x10,0x08,0x04,0x02},
    {0x04,0x04,0x04,0x04,0x04,0,0x04},{0x0E,0x11,0x01,0x02,0x04,0,0x04},{0x18,0x19,0x02,0x04,0x08,0x13,0x03},
    {0x0E,0x08,0x08,0x08,0x08,0x08,0x0E},{0x0E,0x02,0x02,0x02,0x02,0x02,0x0E},{0,0,0x1F,0,0x1F,0,0}};

// ================================================================= settings / state
enum Screen { S_BROWSER, S_GAME, S_PAUSE, S_SETTINGS, S_DISPLAY, S_AUDIO, S_OPTIONS, S_CONTROLS, S_REMAP, S_NSCREENS };
enum { SCALE_ASPECT, SCALE_INTEGER, SCALE_STRETCH };
enum { AA_OFF, AA_SHARP, AA_BICUBIC, AA_FXAA, AA_N };
enum { FILT_NONE, FILT_OLED, FILT_PLASMA, FILT_N };
static const int RES_H[] = {0, 1080, 1440, 2160, 4320};
static const char *RES_NAME[] = {"NATIVE (WINDOW)", "1080P", "1440P", "4K (2160P)", "8K (4320P)"};
static const int KHZ_RATE[] = {32000, 44100, 48000, 96000, 192000};
static const char *KHZ_NAME[] = {"32 KHZ", "44.1 KHZ", "48 KHZ", "96 KHZ", "192 KHZ"};
static const char *AA_NAME[] = {"OFF (PIXEL EXACT)", "SHARP (EDGE AA)", "BICUBIC (SMOOTH)", "FXAA + SHARP"};
static const char *FILT_NAME[] = {"NONE", "OLED", "PLASMA"};

struct Config {
    std::string rom_dir;
    int scale = SCALE_ASPECT, fullscreen = 0, show_fps = 0, slot = 0;
    int res = 3;        // internal render resolution preset
    int aa = AA_SHARP;
    int filter = FILT_NONE, strength = 5;   // strength 0..10
    int khz = 2;        // audio output rate index
    int bind[16];       // retro joypad id -> controller source (-1 none, 0..20 SDL button, 100/101 triggers)
} cfg;
static std::map<std::string, std::string> saved_opts;   // core option key -> value

struct CoreVar { std::string key, desc; std::vector<std::string> values; int cur = 0; };
static std::vector<CoreVar> core_vars;
static bool vars_updated = false;

static SDL_Window *win;
static SDL_GLContext glctx;
static SDL_AudioDeviceID adev;
static int dev_rate = 48000;
static std::vector<SDL_GameController *> pads;
static std::string cfg_dir, sys_dir, save_dir, state_dir, cfg_path;
static Screen screen = S_BROWSER;
static Screen parent_of[S_NSCREENS];
static int saved_sel[S_NSCREENS];
static bool running = true, game_loaded = false;
static std::string cur_rom, browser_dir, message, pending_convert;
static Uint32 message_until;
static float fps_now;

static void *core;
static retro_system_av_info av;
static unsigned pixfmt = RETRO_PIXEL_FORMAT_RGB565;
static bool pressed[2][16];
static const char *RNAME[16] = {"B (LK)", "Y (LP)", "SELECT (COIN)", "START", "UP", "DOWN", "LEFT", "RIGHT",
                                "A (MK)", "X (MP)", "L (HP)", "R (HK)", "L2", "R2", "L3", "R3"};
static const int REMAP_ORDER[] = {4, 5, 6, 7, 1, 9, 10, 0, 8, 11, 12, 13, 3, 2};
static const char *SRC_NAMES[] = {"A", "B", "X", "Y", "BACK", "GUIDE", "START", "L3", "R3", "LB", "RB",
                                  "DPAD UP", "DPAD DOWN", "DPAD LEFT", "DPAD RIGHT", "MISC", "P1", "P2", "P3", "P4", "TOUCH"};

#define CORE_FN(ret, name, args) static ret(*name) args;
CORE_FN(void, c_set_env, (retro_environment_t))
CORE_FN(void, c_set_video, (retro_video_refresh_t))
CORE_FN(void, c_set_audio, (retro_audio_sample_t))
CORE_FN(void, c_set_audio_batch, (retro_audio_sample_batch_t))
CORE_FN(void, c_set_poll, (retro_input_poll_t))
CORE_FN(void, c_set_input, (retro_input_state_t))
CORE_FN(void, c_init, (void))
CORE_FN(void, c_deinit, (void))
CORE_FN(void, c_get_info, (retro_system_info *))
CORE_FN(void, c_get_av, (retro_system_av_info *))
CORE_FN(bool, c_load, (const retro_game_info *))
CORE_FN(void, c_unload, (void))
CORE_FN(void, c_run, (void))
CORE_FN(void, c_reset, (void))
CORE_FN(size_t, c_ser_size, (void))
CORE_FN(bool, c_ser, (void *, size_t))
CORE_FN(bool, c_unser, (const void *, size_t))

static std::string describe_src(int s) {
    if (s < 0) return "NONE"; if (s == 100) return "LT"; if (s == 101) return "RT";
    return s < 21 ? SRC_NAMES[s] : "?";
}
static void set_default_binds() {
    for (int &b : cfg.bind) b = -1;
    cfg.bind[RETRO_DEVICE_ID_JOYPAD_UP] = SDL_CONTROLLER_BUTTON_DPAD_UP;    cfg.bind[RETRO_DEVICE_ID_JOYPAD_DOWN] = SDL_CONTROLLER_BUTTON_DPAD_DOWN;
    cfg.bind[RETRO_DEVICE_ID_JOYPAD_LEFT] = SDL_CONTROLLER_BUTTON_DPAD_LEFT; cfg.bind[RETRO_DEVICE_ID_JOYPAD_RIGHT] = SDL_CONTROLLER_BUTTON_DPAD_RIGHT;
    cfg.bind[RETRO_DEVICE_ID_JOYPAD_B] = SDL_CONTROLLER_BUTTON_A;  cfg.bind[RETRO_DEVICE_ID_JOYPAD_A] = SDL_CONTROLLER_BUTTON_B;
    cfg.bind[RETRO_DEVICE_ID_JOYPAD_Y] = SDL_CONTROLLER_BUTTON_X;  cfg.bind[RETRO_DEVICE_ID_JOYPAD_X] = SDL_CONTROLLER_BUTTON_Y;
    cfg.bind[RETRO_DEVICE_ID_JOYPAD_L] = SDL_CONTROLLER_BUTTON_LEFTSHOULDER; cfg.bind[RETRO_DEVICE_ID_JOYPAD_R] = SDL_CONTROLLER_BUTTON_RIGHTSHOULDER;
    cfg.bind[RETRO_DEVICE_ID_JOYPAD_L2] = 100; cfg.bind[RETRO_DEVICE_ID_JOYPAD_R2] = 101;
    cfg.bind[RETRO_DEVICE_ID_JOYPAD_START] = SDL_CONTROLLER_BUTTON_START; cfg.bind[RETRO_DEVICE_ID_JOYPAD_SELECT] = SDL_CONTROLLER_BUTTON_BACK;
}
static void save_config() {
    FILE *f = fopen(cfg_path.c_str(), "w"); if (!f) return;
    fprintf(f, "rom_dir=%s\nscale=%d\nfullscreen=%d\nshow_fps=%d\nslot=%d\nres=%d\naa=%d\nfilter=%d\nstrength=%d\nkhz=%d\n",
            cfg.rom_dir.c_str(), cfg.scale, cfg.fullscreen, cfg.show_fps, cfg.slot, cfg.res, cfg.aa, cfg.filter, cfg.strength, cfg.khz);
    for (int i = 0; i < 16; i++) fprintf(f, "bind.%d=%d\n", i, cfg.bind[i]);
    for (auto &kv : saved_opts) fprintf(f, "opt.%s=%s\n", kv.first.c_str(), kv.second.c_str());
    fclose(f);
}
static void load_config() {
    set_default_binds();
    cfg.rom_dir = home_dir() + "/Roms/cps3";
    cfg.fullscreen = getenv("SteamDeck") != nullptr;
    FILE *f = fopen(cfg_path.c_str(), "r"); if (!f) return;
    char line[2048];
    while (fgets(line, sizeof line, f)) {
        line[strcspn(line, "\r\n")] = 0;
        char *eq = strchr(line, '='); if (!eq) continue; *eq = 0;
        std::string k = line, v = eq + 1; int n = atoi(v.c_str());
        if (k == "rom_dir") cfg.rom_dir = v;
        else if (k == "scale") cfg.scale = n; else if (k == "fullscreen") cfg.fullscreen = n; else if (k == "show_fps") cfg.show_fps = n;
        else if (k == "slot") cfg.slot = n; else if (k == "res") cfg.res = n; else if (k == "aa") cfg.aa = n;
        else if (k == "filter") cfg.filter = n; else if (k == "strength") cfg.strength = n; else if (k == "khz") cfg.khz = n;
        else if (k.rfind("bind.", 0) == 0) { int i = atoi(k.c_str() + 5); if (i >= 0 && i < 16) cfg.bind[i] = n; }
        else if (k.rfind("opt.", 0) == 0) saved_opts[k.substr(4)] = v;
    }
    fclose(f);
    cfg.scale = std::max(0, std::min(2, cfg.scale)); cfg.res = std::max(0, std::min(4, cfg.res)); cfg.aa = std::max(0, std::min(AA_N - 1, cfg.aa));
    cfg.filter = std::max(0, std::min(FILT_N - 1, cfg.filter)); cfg.strength = std::max(0, std::min(10, cfg.strength)); cfg.khz = std::max(0, std::min(4, cfg.khz));
}
static void notify(const std::string &m, int ms = 2500) { message = m; message_until = SDL_GetTicks() + ms; }
// ================================================================= GL renderer
static const char *VS_FULL = R"(#version 330 core
out vec2 uv;
void main() { vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2)); uv = p; gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }
)";

// Pass 1 (source resolution): sRGB-ish -> linear light, with per-channel phosphor persistence (plasma only; retain = 0 otherwise)
static const char *FS_HIST = R"(#version 330 core
in vec2 uv; out vec4 o;
uniform sampler2D cur; uniform sampler2D prev; uniform vec3 retain; uniform int usePrev;
void main() {
    vec3 c = pow(texture(cur, uv).rgb, vec3(2.2));
    vec3 p = usePrev != 0 ? texture(prev, uv).rgb : vec3(0.0);
    o = vec4(max(c, p * retain), 1.0);
}
)";

// Pass 2 (internal resolution): scaler / anti-aliasing + display model (OLED / plasma)
static const char *FS_MAIN = R"(#version 330 core
in vec2 uv; out vec4 o;
uniform sampler2D src; uniform vec2 srcSize; uniform vec2 outSize;
uniform int aaMode; uniform int filt; uniform float strength; uniform int frame;
const vec3 LUMA = vec3(0.2126, 0.7152, 0.0722);
vec3 fetch(ivec2 i) { i = clamp(i, ivec2(0), ivec2(srcSize) - 1); return texelFetch(src, i, 0).rgb; }
vec4 cubicW(float t) {  // Catmull-Rom
    float t2 = t * t, t3 = t2 * t;
    return vec4(-0.5 * t3 + t2 - 0.5 * t, 1.5 * t3 - 2.5 * t2 + 1.0, -1.5 * t3 + 2.0 * t2 + 0.5 * t, 0.5 * t3 - 0.5 * t2);
}
vec3 sampleSrc(vec2 p) {
    if (aaMode == 0) return fetch(ivec2(floor(p)));
    if (aaMode == 2) {
        vec2 pf = floor(p - 0.5), f = p - 0.5 - pf;
        vec4 wx = cubicW(f.x), wy = cubicW(f.y); vec3 acc = vec3(0.0);
        for (int j = 0; j < 4; j++) for (int i = 0; i < 4; i++) acc += fetch(ivec2(pf) + ivec2(i - 1, j - 1)) * (wx[i] * wy[j]);
        return max(acc, 0.0);
    }
    // sharp bilinear: texel interiors stay crisp, only the boundary (about 1 output pixel wide) is filtered
    vec2 scale = max(outSize / srcSize, vec2(1.0));
    vec2 pf = floor(p), s = p - pf, range = 0.5 - 0.5 / scale, d = s - 0.5;
    vec2 f = (d - clamp(d, -range, range)) * scale + 0.5;
    return textureLod(src, (pf + f) / srcSize, 0.0).rgb;
}
float box(float x, float lo, float hi, float aa) { return smoothstep(lo - aa, lo + aa, x) * (1.0 - smoothstep(hi - aa, hi + aa, x)); }
float hash(vec2 p) { p = fract(p * vec2(443.897, 441.423)); p += dot(p, p.yx + 19.19); return fract((p.x + p.y) * p.x); }
void main() {
    vec2 suv = vec2(uv.x, 1.0 - uv.y);
    vec2 p = suv * srcSize;
    vec3 lin = sampleSrc(p);
    if (filt != 0) {
        float s = strength;
        bool plasma = filt == 2;
        float gx = plasma ? 0.10 : 0.05, gy = plasma ? 0.16 : 0.06;           // black-matrix / rib width (fraction of subpixel / cell)
        vec2 cell = fract(p);
        vec2 aa = 0.5 * srcSize / outSize;                                      // half an output pixel, in cell units
        float my = box(cell.y, gy * 0.5, 1.0 - gy * 0.5, aa.y);
        vec3 m;
        for (int c = 0; c < 3; c++) {                                           // RGB-stripe subpixels
            float lo = float(c) / 3.0 + gx / 6.0, hi = float(c + 1) / 3.0 - gx / 6.0;
            m[c] = box(cell.x, lo, hi, aa.x) * my;
        }
        float g = 3.0 / ((1.0 - gx) * (1.0 - gy));                              // energy-preserving gain
        float depth = 0.45 * s;
        lin *= (1.0 - depth) + depth * m * g;
        float apl = dot(textureLod(src, vec2(0.5), 9.0).rgb, LUMA);             // average picture level for ABL
        if (plasma) {
            lin += 0.06 * s * textureLod(src, suv, 1.5).rgb;                    // cell cross-talk / halation
            lin = lin * (1.0 - 0.0015 * s) + 0.0015 * s;                        // raised black (priming glow)
            lin *= 1.0 - 0.40 * s * smoothstep(0.12, 0.70, apl);               // strong ABL
        } else {
            lin *= 1.0 - 0.16 * s * smoothstep(0.25, 0.80, apl);               // mild ABL, true black
        }
    }
    vec3 v = pow(max(lin, 0.0), vec3(1.0 / 2.2));
    if (filt == 2) {                                                            // subfield-style temporal dither, stronger in the darks
        float n = hash(floor(vec2(suv.x * srcSize.x * 3.0, suv.y * srcSize.y)) + float(frame) * 7.13);
        float amp = (1.0 / 255.0) * (1.0 + 2.5 * (1.0 - dot(v, LUMA))) * strength * 1.5;
        v += (n - 0.5) * 2.0 * amp;
    }
    o = vec4(clamp(v, 0.0, 1.0), 1.0);
}
)";

static const char *FS_FXAA = R"(#version 330 core
in vec2 uv; out vec4 o;
uniform sampler2D img; uniform vec2 size;
void main() {
    vec2 r = 1.0 / size; const vec3 L = vec3(0.299, 0.587, 0.114);
    vec3 nw = textureLod(img, uv + vec2(-1.0, -1.0) * r, 0.0).rgb, ne = textureLod(img, uv + vec2(1.0, -1.0) * r, 0.0).rgb;
    vec3 sw = textureLod(img, uv + vec2(-1.0, 1.0) * r, 0.0).rgb,  se = textureLod(img, uv + vec2(1.0, 1.0) * r, 0.0).rgb;
    vec3 m = textureLod(img, uv, 0.0).rgb;
    float lnw = dot(nw, L), lne = dot(ne, L), lsw = dot(sw, L), lse = dot(se, L), lm = dot(m, L);
    float lmin = min(lm, min(min(lnw, lne), min(lsw, lse))), lmax = max(lm, max(max(lnw, lne), max(lsw, lse)));
    vec2 dir = vec2(-((lnw + lne) - (lsw + lse)), (lnw + lsw) - (lne + lse));
    float dr = max((lnw + lne + lsw + lse) * 0.03125, 1.0 / 128.0);
    float rcp = 1.0 / (min(abs(dir.x), abs(dir.y)) + dr);
    dir = clamp(dir * rcp, vec2(-8.0), vec2(8.0)) * r;
    vec3 a = 0.5 * (textureLod(img, uv + dir * (1.0 / 3.0 - 0.5), 0.0).rgb + textureLod(img, uv + dir * (2.0 / 3.0 - 0.5), 0.0).rgb);
    vec3 b = a * 0.5 + 0.25 * (textureLod(img, uv + dir * -0.5, 0.0).rgb + textureLod(img, uv + dir * 0.5, 0.0).rgb);
    float lb = dot(b, L);
    o = vec4((lb < lmin || lb > lmax) ? a : b, 1.0);
}
)";

// Final pass: box-filter the internal image down (or bilinear up) into the destination rectangle, averaging in linear light
static const char *FS_PRESENT = R"(#version 330 core
in vec2 uv; out vec4 o;
uniform sampler2D img; uniform vec2 imgSize; uniform vec2 destSize;
void main() {
    vec2 r = imgSize / destSize; ivec2 n = clamp(ivec2(ceil(r - 0.001)), ivec2(1), ivec2(8));
    vec3 acc = vec3(0.0);
    for (int j = 0; j < n.y; j++) for (int i = 0; i < n.x; i++) {
        vec2 off = ((vec2(float(i), float(j)) + 0.5) / vec2(n) - 0.5) / destSize;
        acc += pow(textureLod(img, uv + off, 0.0).rgb, vec3(2.2));
    }
    acc /= float(n.x * n.y);
    o = vec4(pow(acc, vec3(1.0 / 2.2)), 1.0);
}
)";

static const char *VS_UI = R"(#version 330 core
layout(location = 0) in vec2 pos; layout(location = 1) in vec2 tc; layout(location = 2) in vec4 col;
uniform vec2 scr; out vec2 vtc; out vec4 vcol;
void main() { vec2 p = pos / scr * 2.0 - 1.0; gl_Position = vec4(p.x, -p.y, 0.0, 1.0); vtc = tc; vcol = col; }
)";
static const char *FS_UI = R"(#version 330 core
in vec2 vtc; in vec4 vcol; out vec4 o; uniform sampler2D atlas;
void main() { o = vec4(vcol.rgb, vcol.a * texture(atlas, vtc).r); }
)";

static GLuint compile_prog(const char *vs, const char *fs, const char *name) {
    auto mk = [&](GLenum t, const char *src) {
        GLuint s = glCreateShader(t); glShaderSource(s, 1, &src, nullptr); glCompileShader(s);
        GLint ok = 0; glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
        if (!ok) { char log[4096]; glGetShaderInfoLog(s, sizeof log, nullptr, log); fprintf(stderr, "shader %s failed:\n%s\n", name, log); exit(2); }
        return s;
    };
    GLuint p = glCreateProgram(); glAttachShader(p, mk(GL_VERTEX_SHADER, vs)); glAttachShader(p, mk(GL_FRAGMENT_SHADER, fs)); glLinkProgram(p);
    GLint ok = 0; glGetProgramiv(p, GL_LINK_STATUS, &ok);
    if (!ok) { char log[4096]; glGetProgramInfoLog(p, sizeof log, nullptr, log); fprintf(stderr, "link %s failed:\n%s\n", name, log); exit(2); }
    return p;
}

struct RT { GLuint tex = 0, fbo = 0; int w = 0, h = 0; };
static GLuint P_HIST, P_MAIN, P_FXAA, P_PRESENT, P_UI, VAO_EMPTY, VAO_UI, VBO_UI, TEX_ATLAS, TEX_GAME;
static int game_w, game_h, game_bpp = 2, max_tex = 8192;
static RT hist[2], sceneA, sceneB; static int hist_cur = 0; static bool hist_valid = false, scene_valid = false;
static RT *final_rt = nullptr;
static int frame_counter = 0;
static int dest_x, dest_y, dest_w, dest_h;     // last presented rectangle (drawable pixels)

static void rt_alloc(RT &r, int w, int h, GLenum ifmt, GLenum fmt, GLenum type, bool mips) {
    if (r.tex && r.w == w && r.h == h) return;
    if (!r.tex) { glGenTextures(1, &r.tex); glGenFramebuffers(1, &r.fbo); }
    glBindTexture(GL_TEXTURE_2D, r.tex);
    glTexImage2D(GL_TEXTURE_2D, 0, ifmt, w, h, 0, fmt, type, nullptr);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, mips ? GL_LINEAR_MIPMAP_LINEAR : GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glBindFramebuffer(GL_FRAMEBUFFER, r.fbo);
    glFramebufferTexture2D(GL_FRAMEBUFFER, GL_COLOR_ATTACHMENT0, GL_TEXTURE_2D, r.tex, 0);
    if (glCheckFramebufferStatus(GL_FRAMEBUFFER) != GL_FRAMEBUFFER_COMPLETE) fprintf(stderr, "framebuffer %dx%d incomplete\n", w, h);
    r.w = w; r.h = h;
}

// ---- UI batch (text + rectangles through a glyph atlas)
struct Col { float r, g, b, a; };
static Col C(int r, int g, int b, int a = 255) { return {r / 255.f, g / 255.f, b / 255.f, a / 255.f}; }
static std::vector<float> ui;
static int UI = 3;
static void quad(float x, float y, float w, float h, float u0, float v0, float u1, float v1, Col c) {
    float v[] = {x, y, u0, v0, x + w, y, u1, v0, x + w, y + h, u1, v1, x, y, u0, v0, x + w, y + h, u1, v1, x, y + h, u0, v1};
    for (int i = 0; i < 6; i++) { ui.insert(ui.end(), v + i * 4, v + i * 4 + 4); ui.push_back(c.r); ui.push_back(c.g); ui.push_back(c.b); ui.push_back(c.a); }
}
static void rect(float x, float y, float w, float h, Col c) { float u = (15 * 8 + 4) / 128.f, v = (7 * 8 + 4) / 64.f; quad(x, y, w, h, u, v, u, v, c); }
static void text(int x, int y, const std::string &s, Col c, int sc = 0) {
    if (!sc) sc = UI;
    for (char ch : s) {
        const char *p = strchr(FONT_CHARS, toupper((unsigned char)ch));
        if (p && *p) {
            int slot = (int)(p - FONT_CHARS) + 1, cx = slot % 16, cy = slot / 16;
            quad((float)x, (float)y, 6.f * sc, 8.f * sc, cx * 8 / 128.f, cy * 8 / 64.f, (cx * 8 + 6) / 128.f, (cy * 8 + 8) / 64.f, c);
        }
        x += 6 * sc;
    }
}
static int tw(const std::string &s, int sc = 0) { return (int)s.size() * 6 * (sc ? sc : UI); }

static void gl_init() {
    P_HIST = compile_prog(VS_FULL, FS_HIST, "hist"); P_MAIN = compile_prog(VS_FULL, FS_MAIN, "main");
    P_FXAA = compile_prog(VS_FULL, FS_FXAA, "fxaa"); P_PRESENT = compile_prog(VS_FULL, FS_PRESENT, "present"); P_UI = compile_prog(VS_UI, FS_UI, "ui");
    glGenVertexArrays(1, &VAO_EMPTY);
    glGenVertexArrays(1, &VAO_UI); glBindVertexArray(VAO_UI); glGenBuffers(1, &VBO_UI); glBindBuffer(GL_ARRAY_BUFFER, VBO_UI);
    glEnableVertexAttribArray(0); glVertexAttribPointer(0, 2, GL_FLOAT, 0, 8 * 4, (void *)0);
    glEnableVertexAttribArray(1); glVertexAttribPointer(1, 2, GL_FLOAT, 0, 8 * 4, (void *)8);
    glEnableVertexAttribArray(2); glVertexAttribPointer(2, 4, GL_FLOAT, 0, 8 * 4, (void *)16);
    // glyph atlas: 16x8 cells of 8x8 texels. slot 0 blank, slots 1.. glyphs, slot 127 solid
    unsigned char atlas[128 * 64]; memset(atlas, 0, sizeof atlas);
    for (int i = 0; FONT_CHARS[i]; i++) {
        int slot = i + 1, cx = slot % 16, cy = slot / 16;
        for (int r = 0; r < 7; r++) for (int col = 0; col < 5; col++) if (FONT[i][r] & (0x10 >> col)) atlas[(cy * 8 + r) * 128 + cx * 8 + col] = 255;
    }
    for (int y = 0; y < 8; y++) for (int x = 0; x < 8; x++) atlas[(7 * 8 + y) * 128 + 15 * 8 + x] = 255;
    glGenTextures(1, &TEX_ATLAS); glBindTexture(GL_TEXTURE_2D, TEX_ATLAS);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_R8, 128, 64, 0, GL_RED, GL_UNSIGNED_BYTE, atlas);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    glGenTextures(1, &TEX_GAME);
    GLint mt = 0; glGetIntegerv(GL_MAX_TEXTURE_SIZE, &mt); if (mt > 0) max_tex = std::min(mt, 8192);
}

static void ui_flush(int ww, int wh) {
    if (ui.empty()) return;
    glViewport(0, 0, ww, wh); glDisable(GL_SCISSOR_TEST); glEnable(GL_BLEND); glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glBindFramebuffer(GL_FRAMEBUFFER, 0);
    glUseProgram(P_UI); glUniform2f(glGetUniformLocation(P_UI, "scr"), (float)ww, (float)wh); glUniform1i(glGetUniformLocation(P_UI, "atlas"), 0);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, TEX_ATLAS);
    glBindVertexArray(VAO_UI); glBindBuffer(GL_ARRAY_BUFFER, VBO_UI);
    glBufferData(GL_ARRAY_BUFFER, (GLsizeiptr)(ui.size() * sizeof(float)), ui.data(), GL_STREAM_DRAW);
    glDrawArrays(GL_TRIANGLES, 0, (GLsizei)(ui.size() / 8));
    glDisable(GL_BLEND); ui.clear();
}

// Called from the core's video callback: upload the frame
static void cb_video(const void *data, unsigned w, unsigned h, size_t pitch) {
    if (!data || !w || !h) return;
    game_bpp = pixfmt == RETRO_PIXEL_FORMAT_XRGB8888 ? 4 : 2;
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, TEX_GAME);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1); glPixelStorei(GL_UNPACK_ROW_LENGTH, (GLint)(pitch / game_bpp));
    GLenum fmt = game_bpp == 4 ? GL_BGRA : GL_RGB, type = game_bpp == 4 ? GL_UNSIGNED_BYTE : GL_UNSIGNED_SHORT_5_6_5;
    if ((int)w != game_w || (int)h != game_h) {
        game_w = w; game_h = h;
        glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, fmt, type, data);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE); glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
        hist_valid = false;
    } else glTexSubImage2D(GL_TEXTURE_2D, 0, 0, 0, w, h, fmt, type, data);
    glPixelStorei(GL_UNPACK_ROW_LENGTH, 0);
}

static void compute_dest(int ww, int wh) {
    float aspect = av.geometry.aspect_ratio > 0 ? av.geometry.aspect_ratio : (game_h ? (float)game_w / game_h : 4.f / 3.f);
    int dw = ww, dh = wh;
    if (cfg.scale != SCALE_STRETCH) {
        dh = wh; dw = (int)(dh * aspect);
        if (cfg.scale == SCALE_INTEGER && game_h) { int s = wh / game_h; if (s >= 1) { dh = game_h * s; dw = (int)(dh * aspect); } }
        if (dw > ww) { dw = ww; dh = (int)(dw / aspect); }
    }
    dest_w = dw; dest_h = dh; dest_x = (ww - dw) / 2; dest_y = (wh - dh) / 2;
}

static void fullscreen_pass() { glBindVertexArray(VAO_EMPTY); glDrawArrays(GL_TRIANGLES, 0, 3); }

// Runs after each core frame: persistence/linearize -> scale+AA+display model -> optional FXAA
static void render_scene(int ww, int wh) {
    if (!game_w) return;
    compute_dest(ww, wh);
    glDisable(GL_SCISSOR_TEST); glDisable(GL_BLEND);
    // pass 1: linear light + plasma phosphor persistence at source resolution
    rt_alloc(hist[0], game_w, game_h, GL_RGBA16F, GL_RGBA, GL_FLOAT, true);
    rt_alloc(hist[1], game_w, game_h, GL_RGBA16F, GL_RGBA, GL_FLOAT, true);
    int prev = hist_cur, nxt = hist_cur ^ 1;
    glBindFramebuffer(GL_FRAMEBUFFER, hist[nxt].fbo); glViewport(0, 0, game_w, game_h);
    glUseProgram(P_HIST);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, TEX_GAME);
    glActiveTexture(GL_TEXTURE0 + 1); glBindTexture(GL_TEXTURE_2D, hist[prev].tex);
    glUniform1i(glGetUniformLocation(P_HIST, "cur"), 0); glUniform1i(glGetUniformLocation(P_HIST, "prev"), 1);
    bool plasma = cfg.filter == FILT_PLASMA;
    glUniform3f(glGetUniformLocation(P_HIST, "retain"), plasma ? 0.02f : 0.f, plasma ? 0.12f : 0.f, plasma ? 0.005f : 0.f);
    glUniform1i(glGetUniformLocation(P_HIST, "usePrev"), hist_valid && plasma ? 1 : 0);
    fullscreen_pass();
    glBindTexture(GL_TEXTURE_2D, 0);
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, hist[nxt].tex); glGenerateMipmap(GL_TEXTURE_2D);
    hist_cur = nxt; hist_valid = true;

    // pass 2: internal-resolution render
    int Rh = RES_H[cfg.res] ? RES_H[cfg.res] : dest_h;
    int Rw = (int)lroundf(Rh * (float)dest_w / std::max(1, dest_h));
    if (Rw > max_tex) { Rh = Rh * max_tex / Rw; Rw = max_tex; }
    if (Rh > max_tex) { Rw = Rw * max_tex / Rh; Rh = max_tex; }
    Rw = std::max(Rw, 16); Rh = std::max(Rh, 16);
    rt_alloc(sceneA, Rw, Rh, GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, false);
    glBindFramebuffer(GL_FRAMEBUFFER, sceneA.fbo); glViewport(0, 0, Rw, Rh);
    glUseProgram(P_MAIN);
    glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, hist[hist_cur].tex);
    glUniform1i(glGetUniformLocation(P_MAIN, "src"), 0);
    glUniform2f(glGetUniformLocation(P_MAIN, "srcSize"), (float)game_w, (float)game_h);
    glUniform2f(glGetUniformLocation(P_MAIN, "outSize"), (float)Rw, (float)Rh);
    glUniform1i(glGetUniformLocation(P_MAIN, "aaMode"), cfg.aa == AA_FXAA ? AA_SHARP : cfg.aa);
    glUniform1i(glGetUniformLocation(P_MAIN, "filt"), cfg.filter);
    glUniform1f(glGetUniformLocation(P_MAIN, "strength"), cfg.strength / 10.f);
    glUniform1i(glGetUniformLocation(P_MAIN, "frame"), frame_counter++);
    fullscreen_pass();
    final_rt = &sceneA;
    if (cfg.aa == AA_FXAA) {
        rt_alloc(sceneB, Rw, Rh, GL_RGBA8, GL_RGBA, GL_UNSIGNED_BYTE, false);
        glBindFramebuffer(GL_FRAMEBUFFER, sceneB.fbo); glViewport(0, 0, Rw, Rh);
        glUseProgram(P_FXAA); glBindTexture(GL_TEXTURE_2D, sceneA.tex);
        glUniform1i(glGetUniformLocation(P_FXAA, "img"), 0); glUniform2f(glGetUniformLocation(P_FXAA, "size"), (float)Rw, (float)Rh);
        fullscreen_pass(); final_rt = &sceneB;
    }
    scene_valid = true;
}

static void present(int ww, int wh) {
    glBindFramebuffer(GL_FRAMEBUFFER, 0); glViewport(0, 0, ww, wh); glDisable(GL_SCISSOR_TEST); glDisable(GL_BLEND);
    glClearColor(0, 0, 0, 1); glClear(GL_COLOR_BUFFER_BIT);
    if (!scene_valid || !final_rt) return;
    glViewport(dest_x, dest_y, dest_w, dest_h); glEnable(GL_SCISSOR_TEST); glScissor(dest_x, dest_y, dest_w, dest_h);
    glUseProgram(P_PRESENT); glActiveTexture(GL_TEXTURE0); glBindTexture(GL_TEXTURE_2D, final_rt->tex);
    glUniform1i(glGetUniformLocation(P_PRESENT, "img"), 0);
    glUniform2f(glGetUniformLocation(P_PRESENT, "imgSize"), (float)final_rt->w, (float)final_rt->h);
    glUniform2f(glGetUniformLocation(P_PRESENT, "destSize"), (float)dest_w, (float)dest_h);
    fullscreen_pass(); glDisable(GL_SCISSOR_TEST);
}

static void save_shot(const std::string &path, int w, int h) {
    std::vector<unsigned char> px((size_t)w * h * 4);
    glBindFramebuffer(GL_FRAMEBUFFER, 0); glReadBuffer(GL_BACK); glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glReadPixels(0, 0, w, h, GL_RGBA, GL_UNSIGNED_BYTE, px.data());
    SDL_Surface *s = SDL_CreateRGBSurfaceWithFormat(0, w, h, 32, SDL_PIXELFORMAT_RGBA32);
    for (int y = 0; y < h; y++) memcpy((unsigned char *)s->pixels + (size_t)y * s->pitch, &px[(size_t)(h - 1 - y) * w * 4], (size_t)w * 4);
    SDL_SaveBMP(s, path.c_str()); SDL_FreeSurface(s);
}
// ================================================================= audio: windowed-sinc resampler + device
struct Resampler {
    static const int TAPS = 16, PH = 256;
    float tab[PH + 1][TAPS];
    double step = 1.0, pos = 8.0;
    std::vector<float> buf;
    void init(double in_rate, double out_rate) {
        step = in_rate / out_rate; double cut = std::min(1.0, 1.0 / step);
        for (int p = 0; p <= PH; p++) {
            double f = (double)p / PH, sum = 0; float *row = tab[p];
            for (int k = 0; k < TAPS; k++) {
                double x = (k - 7) - f, u = x / 8.0;
                double sinc = fabs(x * cut) < 1e-9 ? 1.0 : sin(M_PI * x * cut) / (M_PI * x * cut);
                double w = 0.42 + 0.5 * cos(M_PI * u) + 0.08 * cos(2 * M_PI * u);  // Blackman
                row[k] = (float)(sinc * cut * w); sum += row[k];
            }
            for (int k = 0; k < TAPS; k++) row[k] = (float)(row[k] / sum);
        }
        buf.assign(16, 0.f); pos = 8.0;
    }
    void process(const int16_t *in, size_t frames, std::vector<int16_t> &out) {
        for (size_t i = 0; i < frames * 2; i++) buf.push_back(in[i] / 32768.f);
        size_t n = buf.size() / 2;
        while (pos + 9 < (double)n) {
            long i0 = (long)floor(pos); double f = pos - i0, fi = f * PH; int p0 = (int)fi; float fr = (float)(fi - p0);
            float l = 0, r = 0;
            for (int k = 0; k < TAPS; k++) {
                float w = tab[p0][k] + (tab[p0 + 1][k] - tab[p0][k]) * fr; long idx = i0 - 7 + k;
                l += w * buf[idx * 2]; r += w * buf[idx * 2 + 1];
            }
            out.push_back((int16_t)std::max(-32768.f, std::min(32767.f, l * 32768.f)));
            out.push_back((int16_t)std::max(-32768.f, std::min(32767.f, r * 32768.f)));
            pos += step;
        }
        long drop = (long)floor(pos) - 8;
        if (drop > 0) { buf.erase(buf.begin(), buf.begin() + drop * 2); pos -= drop; }
    }
} rs;
static std::vector<int16_t> rs_out;
static double core_rate = 32000;

static void queue_audio(const int16_t *d, size_t frames) {
    if (!adev) return;
    if (dev_rate == (int)core_rate) { SDL_QueueAudio(adev, d, (Uint32)(frames * 4)); return; }
    rs_out.clear(); rs.process(d, frames, rs_out);
    if (!rs_out.empty()) SDL_QueueAudio(adev, rs_out.data(), (Uint32)(rs_out.size() * 2));
}
static size_t cb_audio_batch(const int16_t *d, size_t frames) { queue_audio(d, frames); return frames; }
static void cb_audio(int16_t l, int16_t r) { int16_t s[2] = {l, r}; queue_audio(s, 1); }

static void open_audio() {
    if (adev) { SDL_CloseAudioDevice(adev); adev = 0; }
    core_rate = av.timing.sample_rate > 8000 ? av.timing.sample_rate : 32000;
    SDL_AudioSpec want{}, have{};
    want.freq = KHZ_RATE[cfg.khz]; want.format = AUDIO_S16SYS; want.channels = 2;
    want.samples = (Uint16)(want.freq >= 150000 ? 8192 : want.freq >= 80000 ? 4096 : 2048);
    adev = SDL_OpenAudioDevice(nullptr, 0, &want, &have, 0);
    if (adev) { dev_rate = have.freq; SDL_PauseAudioDevice(adev, 0); rs.init(core_rate, dev_rate); fprintf(stderr, "audio: core %.0f Hz -> device %d Hz\n", core_rate, dev_rate); }
    else fprintf(stderr, "audio: %s\n", SDL_GetError());
}

// ================================================================= input
static bool src_down(SDL_GameController *gc, int src) {
    if (!gc || src < 0) return false;
    if (src >= 100) return SDL_GameControllerGetAxis(gc, src == 100 ? SDL_CONTROLLER_AXIS_TRIGGERLEFT : SDL_CONTROLLER_AXIS_TRIGGERRIGHT) > 16000;
    return SDL_GameControllerGetButton(gc, (SDL_GameControllerButton)src) != 0;
}
static void cb_poll() {
    SDL_PumpEvents();
    memset(pressed, 0, sizeof pressed);
    for (int p = 0; p < 2; p++) {
        SDL_GameController *gc = p < (int)pads.size() ? pads[p] : nullptr;
        for (int i = 0; i < 16; i++) pressed[p][i] = src_down(gc, cfg.bind[i]);
        if (gc) {
            int x = SDL_GameControllerGetAxis(gc, SDL_CONTROLLER_AXIS_LEFTX), y = SDL_GameControllerGetAxis(gc, SDL_CONTROLLER_AXIS_LEFTY);
            if (x < -16000) pressed[p][RETRO_DEVICE_ID_JOYPAD_LEFT] = true;  if (x > 16000) pressed[p][RETRO_DEVICE_ID_JOYPAD_RIGHT] = true;
            if (y < -16000) pressed[p][RETRO_DEVICE_ID_JOYPAD_UP] = true;    if (y > 16000) pressed[p][RETRO_DEVICE_ID_JOYPAD_DOWN] = true;
        }
    }
    const Uint8 *k = SDL_GetKeyboardState(nullptr);
    auto K = [&](SDL_Scancode s) { return k[s] != 0; };
    bool *p1 = pressed[0];
    p1[RETRO_DEVICE_ID_JOYPAD_UP] |= K(SDL_SCANCODE_UP);     p1[RETRO_DEVICE_ID_JOYPAD_DOWN] |= K(SDL_SCANCODE_DOWN);
    p1[RETRO_DEVICE_ID_JOYPAD_LEFT] |= K(SDL_SCANCODE_LEFT); p1[RETRO_DEVICE_ID_JOYPAD_RIGHT] |= K(SDL_SCANCODE_RIGHT);
    p1[RETRO_DEVICE_ID_JOYPAD_Y] |= K(SDL_SCANCODE_A); p1[RETRO_DEVICE_ID_JOYPAD_X] |= K(SDL_SCANCODE_S); p1[RETRO_DEVICE_ID_JOYPAD_L] |= K(SDL_SCANCODE_D);
    p1[RETRO_DEVICE_ID_JOYPAD_B] |= K(SDL_SCANCODE_Z); p1[RETRO_DEVICE_ID_JOYPAD_A] |= K(SDL_SCANCODE_X); p1[RETRO_DEVICE_ID_JOYPAD_R] |= K(SDL_SCANCODE_C);
    p1[RETRO_DEVICE_ID_JOYPAD_START] |= K(SDL_SCANCODE_RETURN);
    p1[RETRO_DEVICE_ID_JOYPAD_SELECT] |= K(SDL_SCANCODE_RSHIFT) || K(SDL_SCANCODE_BACKSPACE);
}
static int16_t cb_input(unsigned port, unsigned dev, unsigned, unsigned id) {
    if (port > 1 || (dev & 0xFF) != RETRO_DEVICE_JOYPAD) return 0;
    if (id == RETRO_DEVICE_ID_JOYPAD_MASK) { int m = 0; for (int i = 0; i < 16; i++) if (pressed[port][i]) m |= 1 << i; return (int16_t)m; }
    return id < 16 && pressed[port][id];
}

// ================================================================= libretro environment, core options
static void RETRO_CALLCONV cb_log(enum retro_log_level lvl, const char *fmt, ...) {
    if (lvl < RETRO_LOG_INFO) return;
    va_list a; va_start(a, fmt); vfprintf(stderr, fmt, a); va_end(a);
}
static void parse_variables(const retro_variable *v) {
    std::vector<CoreVar> nv;
    for (; v && v->key; v++) {
        CoreVar cv; cv.key = v->key; std::string s = v->value ? v->value : "";
        size_t semi = s.find(';'); if (semi == std::string::npos) continue;
        cv.desc = s.substr(0, semi); std::string rest = s.substr(semi + 1); while (!rest.empty() && rest[0] == ' ') rest.erase(0, 1);
        size_t pos = 0;
        while (pos <= rest.size()) { size_t bar = rest.find('|', pos); if (bar == std::string::npos) bar = rest.size(); cv.values.push_back(rest.substr(pos, bar - pos)); pos = bar + 1; }
        auto it = saved_opts.find(cv.key);
        if (it != saved_opts.end()) for (size_t i = 0; i < cv.values.size(); i++) if (cv.values[i] == it->second) cv.cur = (int)i;
        if (!cv.values.empty()) { nv.push_back(cv); fprintf(stderr, "option %s = %s\n", cv.key.c_str(), cv.values[cv.cur].c_str()); }
    }
    core_vars = nv;
}
static bool cb_env(unsigned cmd, void *data) {
    switch (cmd & 0xFFFF) {
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT: {
        unsigned f = *(unsigned *)data;
        if (f != RETRO_PIXEL_FORMAT_XRGB8888 && f != RETRO_PIXEL_FORMAT_RGB565) return false;
        pixfmt = f; return true; }
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY: *(const char **)data = sys_dir.c_str(); return true;
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY: *(const char **)data = save_dir.c_str(); return true;
    case RETRO_ENVIRONMENT_GET_LOG_INTERFACE: ((retro_log_callback *)data)->log = cb_log; return true;
    case RETRO_ENVIRONMENT_GET_CAN_DUPE: *(bool *)data = true; return true;
    case RETRO_ENVIRONMENT_SET_ROTATION: case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS: case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
    case RETRO_ENVIRONMENT_SET_PERFORMANCE_LEVEL: return true;
    case RETRO_ENVIRONMENT_SET_VARIABLES: parse_variables((const retro_variable *)data); return true;
    case RETRO_ENVIRONMENT_SET_GEOMETRY: av.geometry = *(retro_game_geometry *)data; return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
        retro_variable *rv = (retro_variable *)data;
        for (auto &cv : core_vars) if (cv.key == rv->key) { rv->value = cv.values[cv.cur].c_str(); return true; }
        rv->value = nullptr; return false; }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE: *(bool *)data = vars_updated; vars_updated = false; return true;
    default: return false;
    }
}
static bool load_core(const std::string &path) {
    core = dlopen(path.c_str(), RTLD_NOW | RTLD_LOCAL);
    if (!core) { fprintf(stderr, "dlopen: %s\n", dlerror()); return false; }
#define SYM(var, name) *(void **)(&var) = dlsym(core, name); if (!var) { fprintf(stderr, "missing %s\n", name); return false; }
    SYM(c_set_env, "retro_set_environment") SYM(c_set_video, "retro_set_video_refresh") SYM(c_set_audio, "retro_set_audio_sample")
    SYM(c_set_audio_batch, "retro_set_audio_sample_batch") SYM(c_set_poll, "retro_set_input_poll") SYM(c_set_input, "retro_set_input_state")
    SYM(c_init, "retro_init") SYM(c_deinit, "retro_deinit") SYM(c_get_info, "retro_get_system_info") SYM(c_get_av, "retro_get_system_av_info")
    SYM(c_load, "retro_load_game") SYM(c_unload, "retro_unload_game") SYM(c_run, "retro_run") SYM(c_reset, "retro_reset")
    SYM(c_ser_size, "retro_serialize_size") SYM(c_ser, "retro_serialize") SYM(c_unser, "retro_unserialize")
    c_set_env(cb_env); c_init();
    c_set_video(cb_video); c_set_audio(cb_audio); c_set_audio_batch(cb_audio_batch); c_set_poll(cb_poll); c_set_input(cb_input);
    return true;
}
static void close_game() {
    if (game_loaded) { c_unload(); game_loaded = false; }
    if (adev) { SDL_CloseAudioDevice(adev); adev = 0; }
    game_w = game_h = 0; scene_valid = false; hist_valid = false;
}
static bool launch(const std::string &path) {
    close_game();
    retro_system_info si{}; c_get_info(&si);
    retro_game_info gi{}; gi.path = path.c_str();
    std::vector<char> buf;
    if (!si.need_fullpath) {
        FILE *f = fopen(path.c_str(), "rb");
        if (!f) { notify("CANNOT OPEN FILE"); return false; }
        fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
        buf.resize(n); if (fread(buf.data(), 1, n, f) != (size_t)n) { fclose(f); return false; } fclose(f);
        gi.data = buf.data(); gi.size = buf.size();
    }
    if (!c_load(&gi)) { notify("FAILED TO LOAD GAME (BAD CP3, OR ZIP MISSING BIOS)", 4000); return false; }
    c_get_av(&av);
    game_loaded = true; cur_rom = path;
    open_audio();
    screen = S_GAME;
    return true;
}
// Convert a MAME-style CPS3 zip set into a single-file .cp3 (the core writes it while loading)
static void convert_to_cp3(const std::string &zip) {
    close_game();
    std::string out = zip.substr(0, zip.find_last_of('.')) + ".cp3";
    setenv("CPS3_DUMP_CP3", out.c_str(), 1);
    retro_game_info gi{}; gi.path = zip.c_str();
    remove(out.c_str());
    bool ok = c_load(&gi);
    unsetenv("CPS3_DUMP_CP3");
    if (ok) c_unload();
    long sz = file_size(out);
    if (ok && sz > 0) notify("CREATED " + base_noext(out) + ".CP3 (" + std::to_string(sz / 1048576) + " MB)", 4000);
    else { remove(out.c_str()); notify("CONVERSION FAILED (NOT A CPS3 SET, OR MISSING PARENT/BIOS ZIP)", 5000); }
}

static std::string state_path() { return state_dir + "/" + base_noext(cur_rom) + ".state" + std::to_string(cfg.slot); }
static void save_state() {
    size_t n = c_ser_size(); std::vector<char> b(n);
    if (n && c_ser(b.data(), n)) {
        FILE *f = fopen(state_path().c_str(), "wb");
        if (f) { fwrite(b.data(), 1, n, f); fclose(f); notify("STATE SAVED TO SLOT " + std::to_string(cfg.slot)); return; }
    }
    notify("SAVE STATE FAILED");
}
static void load_state() {
    FILE *f = fopen(state_path().c_str(), "rb");
    if (!f) { notify("SLOT " + std::to_string(cfg.slot) + " IS EMPTY"); return; }
    fseek(f, 0, SEEK_END); long n = ftell(f); fseek(f, 0, SEEK_SET);
    std::vector<char> b(n); size_t got = fread(b.data(), 1, n, f); fclose(f);
    notify(got == (size_t)n && c_unser(b.data(), n) ? "STATE LOADED FROM SLOT " + std::to_string(cfg.slot) : "LOAD STATE FAILED");
}
// ================================================================= menus
struct Item { std::string label; std::function<void(int)> act; };
static int sel = 0, remap_id = -1, convert_delay = 0; static Uint32 remap_deadline;
static std::vector<std::string> browser_names, browser_titles; static std::vector<bool> browser_isdir;

static std::string cp3_title(const std::string &p) {
    FILE *f = fopen(p.c_str(), "rb"); if (!f) return "";
    unsigned char h[0x64]; std::string t;
    if (fread(h, 1, sizeof h, f) == sizeof h && memcmp(h, "CP3P", 4) == 0) { t.assign((char *)h + 36, strnlen((char *)h + 36, 63)); }
    fclose(f); return t;
}
static void scan_browser() {
    browser_names.clear(); browser_titles.clear(); browser_isdir.clear();
    std::vector<std::pair<std::string, bool>> v;
    if (DIR *d = opendir(browser_dir.c_str())) {
        while (dirent *e = readdir(d)) {
            std::string n = e->d_name; if (n == "." || n[0] == '.') continue;
            bool dir = is_dir(browser_dir + "/" + n);
            if (dir || ends_with_ci(n, ".zip") || ends_with_ci(n, ".cp3") || ends_with_ci(n, ".7z")) v.push_back({n, dir});
        }
        closedir(d);
    }
    std::sort(v.begin(), v.end(), [](auto &a, auto &b) { if (a.second != b.second) return a.second > b.second; return strcasecmp(a.first.c_str(), b.first.c_str()) < 0; });
    browser_names.push_back(".."); browser_titles.push_back(""); browser_isdir.push_back(true);
    for (auto &p : v) {
        browser_names.push_back(p.first); browser_isdir.push_back(p.second);
        browser_titles.push_back(!p.second && ends_with_ci(p.first, ".cp3") ? cp3_title(browser_dir + "/" + p.first) : "");
    }
    sel = 0;
}
static void browser_up() { if (browser_dir.size() > 1) { size_t s = browser_dir.find_last_of('/'); browser_dir = s == 0 ? "/" : browser_dir.substr(0, s); scan_browser(); } }
static std::string browser_path(int i) { return (browser_dir == "/" ? "" : browser_dir) + "/" + browser_names[i]; }
static void browser_confirm() {
    if (sel < 0 || sel >= (int)browser_names.size()) return;
    if (browser_names[sel] == "..") { browser_up(); return; }
    if (browser_isdir[sel]) { browser_dir = browser_path(sel); scan_browser(); }
    else { cfg.rom_dir = browser_dir; save_config(); launch(browser_path(sel)); }
}
static void browser_convert() {
    if (sel < 0 || sel >= (int)browser_names.size() || browser_isdir[sel]) return;
    const std::string &n = browser_names[sel];
    if (ends_with_ci(n, ".cp3")) { notify("ALREADY A CP3"); return; }
    pending_convert = browser_path(sel); convert_delay = 2; notify("CONVERTING " + upper(base_noext(n)) + " TO CP3...", 60000);
}

static void go(Screen child) { saved_sel[screen] = sel; parent_of[child] = screen; screen = child; sel = 0; }
static void go_back() { Screen p = parent_of[screen]; screen = p; sel = saved_sel[p]; }
static void apply_fullscreen() { SDL_SetWindowFullscreen(win, cfg.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0); }
static CoreVar *region_var() {
    for (auto &cv : core_vars) if (upper(cv.desc).find("REGION") != std::string::npos) return &cv;
    return nullptr;
}
static void cycle_var(CoreVar &cv, int d) {
    int n = (int)cv.values.size(); cv.cur = (cv.cur + n + d) % n;
    saved_opts[cv.key] = cv.values[cv.cur]; vars_updated = true; save_config();
    if (&cv == region_var()) { c_reset(); notify("REGION: " + upper(cv.values[cv.cur]) + " - GAME RESET"); }   // region is read from the BIOS at boot
}
template <class T> static int cyc(int v, int d, int n) { (void)sizeof(T); return (v + n + d) % n; }

static std::vector<Item> menu_items() {
    std::vector<Item> it;
    auto back = [](int d) { if (!d) go_back(); };
    if (screen == S_PAUSE) {
        it.push_back({"RESUME", [](int d) { if (!d) screen = S_GAME; }});
        if (CoreVar *rv = region_var()) { it.push_back({"REGION < " + upper(rv->values[rv->cur]) + " >", [rv](int d) { if (d) cycle_var(*rv, d); }}); }
        it.push_back({"SAVE STATE", [](int d) { if (!d) save_state(); }});
        it.push_back({"LOAD STATE", [](int d) { if (!d) { load_state(); screen = S_GAME; } }});
        it.push_back({"STATE SLOT < " + std::to_string(cfg.slot) + " >", [](int d) { if (d) cfg.slot = (cfg.slot + 10 + d) % 10; }});
        it.push_back({"RESET GAME", [](int d) { if (!d) { c_reset(); screen = S_GAME; } }});
        if (!core_vars.empty()) it.push_back({"GAME OPTIONS (DIPS)", [](int d) { if (!d) go(S_OPTIONS); }});
        it.push_back({"DISPLAY OPTIONS", [](int d) { if (!d) go(S_DISPLAY); }});
        it.push_back({"AUDIO OPTIONS", [](int d) { if (!d) go(S_AUDIO); }});
        it.push_back({"CONTROLS", [](int d) { if (!d) go(S_CONTROLS); }});
        it.push_back({"CLOSE GAME", [](int d) { if (!d) { close_game(); screen = S_BROWSER; scan_browser(); } }});
        it.push_back({"QUIT", [](int d) { if (!d) running = false; }});
    } else if (screen == S_SETTINGS) {
        it.push_back({"DISPLAY OPTIONS", [](int d) { if (!d) go(S_DISPLAY); }});
        it.push_back({"AUDIO OPTIONS", [](int d) { if (!d) go(S_AUDIO); }});
        it.push_back({"CONTROLS", [](int d) { if (!d) go(S_CONTROLS); }});
        it.push_back({"BACK", back});
    } else if (screen == S_DISPLAY) {
        it.push_back({std::string("SCALING < ") + (cfg.scale == 0 ? "KEEP ASPECT" : cfg.scale == 1 ? "INTEGER" : "STRETCH") + " >", [](int d) { if (d) { cfg.scale = cyc<int>(cfg.scale, d, 3); save_config(); } }});
        it.push_back({std::string("RENDER RES < ") + RES_NAME[cfg.res] + " >", [](int d) { if (d) { cfg.res = cyc<int>(cfg.res, d, 5); save_config(); } }});
        it.push_back({std::string("ANTI-ALIAS < ") + AA_NAME[cfg.aa] + " >", [](int d) { if (d) { cfg.aa = cyc<int>(cfg.aa, d, AA_N); save_config(); } }});
        it.push_back({std::string("SCREEN < ") + FILT_NAME[cfg.filter] + " >", [](int d) { if (d) { cfg.filter = cyc<int>(cfg.filter, d, FILT_N); save_config(); } }});
        it.push_back({"FILTER STRENGTH < " + std::to_string(cfg.strength * 10) + "% >", [](int d) { if (d) { cfg.strength = std::max(0, std::min(10, cfg.strength + d)); save_config(); } }});
        it.push_back({std::string("FULLSCREEN < ") + (cfg.fullscreen ? "ON" : "OFF") + " >", [](int d) { if (d) { cfg.fullscreen ^= 1; apply_fullscreen(); save_config(); } }});
        it.push_back({std::string("SHOW FPS < ") + (cfg.show_fps ? "ON" : "OFF") + " >", [](int d) { if (d) { cfg.show_fps ^= 1; save_config(); } }});
        it.push_back({"BACK", back});
    } else if (screen == S_AUDIO) {
        it.push_back({std::string("OUTPUT RATE < ") + KHZ_NAME[cfg.khz] + " >", [](int d) { if (d) { cfg.khz = cyc<int>(cfg.khz, d, 5); save_config(); if (game_loaded) open_audio(); } }});
        it.push_back({"CORE AUDIO IS " + std::to_string((int)(core_rate / 1000.0 + 0.5)) + " KHZ - RESAMPLED WITH WINDOWED SINC", [](int) {}});
        it.push_back({"BACK", back});
    } else if (screen == S_OPTIONS) {
        for (auto &cv : core_vars) { if (upper(cv.desc).find("SAMPLERATE") != std::string::npos) continue; CoreVar *p = &cv; it.push_back({cv.desc + " < " + cv.values[cv.cur] + " >", [p](int d) { if (d) cycle_var(*p, d); }}); }
        it.push_back({"BACK", back});
    } else if (screen == S_CONTROLS) {
        for (int id : REMAP_ORDER)
            it.push_back({std::string(RNAME[id]) + ": " + describe_src(cfg.bind[id]), [id](int d) { if (!d) { remap_id = id; remap_deadline = SDL_GetTicks() + 8000; saved_sel[S_CONTROLS] = sel; screen = S_REMAP; } }});
        it.push_back({"RESET TO DEFAULTS", [](int d) { if (!d) { set_default_binds(); save_config(); notify("CONTROLS RESET"); } }});
        it.push_back({"BACK", back});
    }
    return it;
}
static void remap_assign(int src) {
    int old = cfg.bind[remap_id];
    for (int i = 0; i < 16; i++) if (i != remap_id && cfg.bind[i] == src) cfg.bind[i] = old;
    cfg.bind[remap_id] = src; save_config(); screen = S_CONTROLS; sel = saved_sel[S_CONTROLS]; remap_id = -1;
}
static void menu_nav(int dx, int dy, bool confirm, bool back) {
    if (screen == S_BROWSER) {
        int n = (int)browser_names.size();
        if (dy) sel = std::abs(dy) == 1 ? (sel + n + dy) % n : std::max(0, std::min(n - 1, sel + dy));
        if (confirm) browser_confirm();
        if (back) browser_up();
        return;
    }
    auto items = menu_items(); int n = (int)items.size(); if (!n) return;
    if (dy) sel = std::abs(dy) == 1 ? (sel + n + dy) % n : std::max(0, std::min(n - 1, sel + dy));
    if (sel >= n) sel = n - 1;
    if (dx) items[sel].act(dx);
    if (confirm) items[sel].act(0);
    if (back) { if (screen == S_PAUSE) screen = S_GAME; else go_back(); }
}

static void draw_menu(int ww, int wh) {
    UI = std::max(2, wh / 220);
    int lh = 11 * UI, small = std::max(1, UI - 1);
    std::string title, hint; std::vector<std::string> rows;
    switch (screen) {
    case S_BROWSER:
        title = "CPS3 DECK - SELECT A GAME"; hint = "A: PLAY  B: UP  X: ZIP TO CP3  SELECT: SETTINGS  START: QUIT";
        for (size_t i = 0; i < browser_names.size(); i++) rows.push_back(browser_isdir[i] ? "[" + browser_names[i] + "]" : (!browser_titles[i].empty() ? browser_titles[i] + "  [" + browser_names[i] + "]" : browser_names[i]));
        break;
    case S_REMAP: title = "REMAP"; hint = "PRESS A CONTROLLER BUTTON  (ESC: CANCEL)"; rows.push_back(std::string("PRESS BUTTON FOR ") + RNAME[remap_id]); break;
    default:
        title = screen == S_PAUSE ? "PAUSED" : screen == S_SETTINGS ? "SETTINGS" : screen == S_DISPLAY ? "DISPLAY OPTIONS" : screen == S_AUDIO ? "AUDIO OPTIONS" : screen == S_OPTIONS ? "GAME OPTIONS" : "CONTROLS";
        hint = "A: SELECT   B: BACK   LEFT/RIGHT: CHANGE";
        for (auto &i : menu_items()) rows.push_back(i.label);
    }
    int panel_w = ww; bool side = screen == S_DISPLAY && game_loaded;
    if (screen == S_BROWSER) rect(0, 0, (float)ww, (float)wh, C(8, 10, 28));
    else if (side) { int mx = 0; for (auto &r : rows) mx = std::max(mx, tw(r)); panel_w = std::min(ww, mx + UI * 28); rect(0, 0, (float)panel_w, (float)wh, C(0, 0, 20, 220)); }
    else rect(0, 0, (float)ww, (float)wh, C(0, 0, 20, 205));
    Col white = C(235, 235, 245), gold = C(255, 200, 60), grey = C(140, 150, 175);
    text((panel_w - tw(title, UI + 1)) / 2, UI * 6, title, gold, UI + 1);
    if (screen == S_BROWSER) text(UI * 6, UI * 22, browser_dir, grey, small);
    int top = UI * 36, visible = std::max(3, (wh - top - UI * 24) / lh);
    int first = std::max(0, std::min(sel - visible / 2, (int)rows.size() - visible));
    for (int i = first; i < (int)rows.size() && i < first + visible; i++) {
        int y = top + (i - first) * lh; bool s = i == sel || screen == S_REMAP;
        if (s) rect((float)(UI * 4), (float)(y - UI * 2), (float)(panel_w - UI * 8), (float)lh, C(40, 70, 150));
        std::string row = rows[i]; int maxc = (panel_w - UI * 20) / (6 * UI); if ((int)row.size() > maxc) row = row.substr(0, maxc - 1) + ">";
        text(UI * 10, y, row, s ? white : grey);
    }
    text(std::max(0, (panel_w - tw(hint, small)) / 2), wh - UI * 12, hint, grey, small);
}
static void draw_overlay(int ww, int wh) {
    UI = std::max(2, wh / 220);
    if (cfg.show_fps && screen == S_GAME) text(UI * 4, UI * 4, std::to_string((int)(fps_now + 0.5f)) + " FPS", C(255, 200, 60));
    if (message_until > SDL_GetTicks() && !message.empty()) {
        int w = tw(message), x = std::max(0, (ww - w) / 2), y = wh - UI * 30;
        rect((float)(x - UI * 4), (float)(y - UI * 3), (float)(w + UI * 8), (float)(UI * 14), C(0, 0, 0, 215));
        text(x, y, message, C(255, 255, 255));
    }
}

// ================================================================= controllers & events
static void add_pad(int idx) {
    if (!SDL_IsGameController(idx)) return;
    if (SDL_GameController *gc = SDL_GameControllerOpen(idx)) {
        for (auto *p : pads) if (p == gc) return;
        pads.push_back(gc); notify(std::string("CONTROLLER: ") + upper(SDL_GameControllerName(gc)));
    }
}
static void remove_pad(SDL_JoystickID id) {
    for (size_t i = 0; i < pads.size(); i++)
        if (SDL_JoystickInstanceID(SDL_GameControllerGetJoystick(pads[i])) == id) { SDL_GameControllerClose(pads[i]); pads.erase(pads.begin() + i); notify("CONTROLLER DISCONNECTED"); return; }
}
static void pause_game() { if (game_loaded) { screen = S_PAUSE; sel = 0; if (adev) SDL_ClearQueuedAudio(adev); } }

static void handle_event(const SDL_Event &e) {
    static int axis_dir[2];
    switch (e.type) {
    case SDL_QUIT: running = false; break;
    case SDL_CONTROLLERDEVICEADDED: add_pad(e.cdevice.which); break;
    case SDL_CONTROLLERDEVICEREMOVED: remove_pad(e.cdevice.which); break;
    case SDL_KEYDOWN:
        if (e.key.keysym.sym == SDLK_F11 || (e.key.keysym.sym == SDLK_RETURN && (e.key.keysym.mod & KMOD_ALT))) { cfg.fullscreen ^= 1; apply_fullscreen(); save_config(); }
        else if (screen == S_REMAP && e.key.keysym.sym == SDLK_ESCAPE) { screen = S_CONTROLS; sel = saved_sel[S_CONTROLS]; }
        else if (screen == S_GAME && e.key.keysym.sym == SDLK_ESCAPE) pause_game();
        else if (screen != S_GAME && screen != S_REMAP) {
            switch (e.key.keysym.sym) {
            case SDLK_UP: menu_nav(0, -1, false, false); break;   case SDLK_DOWN: menu_nav(0, 1, false, false); break;
            case SDLK_LEFT: menu_nav(-1, 0, false, false); break; case SDLK_RIGHT: menu_nav(1, 0, false, false); break;
            case SDLK_PAGEUP: menu_nav(0, -8, false, false); break; case SDLK_PAGEDOWN: menu_nav(0, 8, false, false); break;
            case SDLK_RETURN: menu_nav(0, 0, true, false); break;
            case SDLK_c: if (screen == S_BROWSER) browser_convert(); break;
            case SDLK_F1: if (screen == S_BROWSER) go(S_SETTINGS); break;
            case SDLK_ESCAPE: case SDLK_BACKSPACE: if (screen == S_BROWSER && e.key.keysym.sym == SDLK_ESCAPE) running = false; else menu_nav(0, 0, false, true); break;
            }
        }
        break;
    case SDL_CONTROLLERBUTTONDOWN: {
        int b = e.cbutton.button;
        if (screen == S_GAME) {
            SDL_GameController *gc = SDL_GameControllerFromInstanceID(e.cbutton.which);
            bool chord = (b == SDL_CONTROLLER_BUTTON_START && SDL_GameControllerGetButton(gc, SDL_CONTROLLER_BUTTON_BACK)) ||
                         (b == SDL_CONTROLLER_BUTTON_BACK && SDL_GameControllerGetButton(gc, SDL_CONTROLLER_BUTTON_START));
            if (chord || b == SDL_CONTROLLER_BUTTON_GUIDE) pause_game();
        } else if (screen == S_REMAP) remap_assign(b);
        else switch (b) {
            case SDL_CONTROLLER_BUTTON_DPAD_UP: menu_nav(0, -1, false, false); break;
            case SDL_CONTROLLER_BUTTON_DPAD_DOWN: menu_nav(0, 1, false, false); break;
            case SDL_CONTROLLER_BUTTON_DPAD_LEFT: menu_nav(-1, 0, false, false); break;
            case SDL_CONTROLLER_BUTTON_DPAD_RIGHT: menu_nav(1, 0, false, false); break;
            case SDL_CONTROLLER_BUTTON_A: menu_nav(0, 0, true, false); break;
            case SDL_CONTROLLER_BUTTON_B: menu_nav(0, 0, false, true); break;
            case SDL_CONTROLLER_BUTTON_X: if (screen == S_BROWSER) browser_convert(); break;
            case SDL_CONTROLLER_BUTTON_BACK: if (screen == S_BROWSER) go(S_SETTINGS); break;
            case SDL_CONTROLLER_BUTTON_LEFTSHOULDER: menu_nav(0, -8, false, false); break;
            case SDL_CONTROLLER_BUTTON_RIGHTSHOULDER: menu_nav(0, 8, false, false); break;
            case SDL_CONTROLLER_BUTTON_START: if (screen == S_BROWSER) running = false; else if (screen == S_PAUSE) screen = S_GAME; break;
        }
        break; }
    case SDL_CONTROLLERAXISMOTION: {
        int a = e.caxis.axis, v = e.caxis.value;
        if (screen == S_REMAP && (a == SDL_CONTROLLER_AXIS_TRIGGERLEFT || a == SDL_CONTROLLER_AXIS_TRIGGERRIGHT) && v > 20000)
            remap_assign(a == SDL_CONTROLLER_AXIS_TRIGGERLEFT ? 100 : 101);
        else if (screen != S_GAME && screen != S_REMAP && (a == SDL_CONTROLLER_AXIS_LEFTY || a == SDL_CONTROLLER_AXIS_LEFTX)) {
            int k = a == SDL_CONTROLLER_AXIS_LEFTY ? 0 : 1, nd = v < -20000 ? -1 : v > 20000 ? 1 : 0;
            if (nd != axis_dir[k]) { axis_dir[k] = nd; if (nd) { if (k == 0) menu_nav(0, nd, false, false); else menu_nav(nd, 0, false, false); } }
        }
        break; }
    }
}

// ================================================================= main
int main(int argc, char **argv) {
    std::string core_path, rom_arg, shot, open_screen; int test_frames = 0, skip_frames = 0; bool test_mode = false;
    int o_res = -1, o_aa = -1, o_filt = -1, o_str = -1, o_khz = -1, o_scale = -1; std::string convert_arg;
    char exe[1024]; ssize_t n = readlink("/proc/self/exe", exe, sizeof exe - 1); exe[n > 0 ? n : 0] = 0;
    core_path = std::string(dirname(exe)) + "/fbalpha2012_cps3_libretro.so";
    for (int i = 1; i < argc; i++) {
        std::string a = argv[i]; auto nx = [&]() { return i + 1 < argc ? std::string(argv[++i]) : std::string(); };
        if (a == "--core") core_path = nx(); else if (a == "--shot") { shot = nx(); test_mode = true; }
        else if (a == "--frames") { test_frames = atoi(nx().c_str()); test_mode = true; }
        else if (a == "--open") open_screen = nx(); else if (a == "--res") o_res = atoi(nx().c_str()); else if (a == "--aa") o_aa = atoi(nx().c_str());
        else if (a == "--filter") o_filt = atoi(nx().c_str()); else if (a == "--strength") o_str = atoi(nx().c_str());
        else if (a == "--khz") o_khz = atoi(nx().c_str()); else if (a == "--scale") o_scale = atoi(nx().c_str());
        else if (a == "--convert") convert_arg = nx(); else if (a == "--skip") { skip_frames = atoi(nx().c_str()); test_mode = true; }
        else if (a == "--help") { printf("usage: cps3deck [--core file.so] [--convert game.zip] [game.cp3|game.zip]\n"); return 0; }
        else rom_arg = a;
    }
    const char *xdg = getenv("XDG_CONFIG_HOME");
    cfg_dir = (xdg ? std::string(xdg) : home_dir() + "/.config") + "/cps3deck";
    sys_dir = cfg_dir + "/system"; save_dir = cfg_dir + "/saves"; state_dir = cfg_dir + "/states"; cfg_path = cfg_dir + "/config.ini";
    for (auto &d : {cfg_dir, sys_dir, save_dir, state_dir}) mkdirs(d);
    load_config();
    if (o_res >= 0) cfg.res = o_res; if (o_aa >= 0) cfg.aa = o_aa; if (o_filt >= 0) cfg.filter = o_filt; if (o_str >= 0) cfg.strength = o_str;
    if (o_khz >= 0) cfg.khz = o_khz; if (o_scale >= 0) cfg.scale = o_scale;
    if (test_mode) cfg.fullscreen = 0;

    SDL_SetHint(SDL_HINT_JOYSTICK_ALLOW_BACKGROUND_EVENTS, "1");
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_GAMECONTROLLER | SDL_INIT_JOYSTICK) != 0) { fprintf(stderr, "SDL: %s\n", SDL_GetError()); return 1; }
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3); SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE); SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    win = SDL_CreateWindow("CPS3 Deck", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, 1280, 800, SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE | (cfg.fullscreen ? SDL_WINDOW_FULLSCREEN_DESKTOP : 0));
    if (!win) { fprintf(stderr, "window: %s\n", SDL_GetError()); return 1; }
    glctx = SDL_GL_CreateContext(win);
    if (!glctx) { fprintf(stderr, "OpenGL 3.3 context: %s\n", SDL_GetError()); return 1; }
    SDL_GL_SetSwapInterval(0);
    if (!load_gl()) return 1;
    fprintf(stderr, "GL: %s / %s\n", glGetString(GL_VERSION), glGetString(GL_RENDERER));
    gl_init();
    SDL_ShowCursor(SDL_DISABLE);
    for (int i = 0; i < SDL_NumJoysticks(); i++) add_pad(i);
    if (!load_core(core_path)) { fprintf(stderr, "could not load core %s\n", core_path.c_str()); return 1; }

    if (!convert_arg.empty()) {     // headless-style conversion: cps3deck --convert sfiiin.zip
        convert_to_cp3(convert_arg); fprintf(stderr, "%s\n", message.c_str()); c_deinit(); SDL_Quit(); return message.rfind("CREATED", 0) == 0 ? 0 : 1;
    }
    browser_dir = is_dir(cfg.rom_dir) ? cfg.rom_dir : home_dir();
    scan_browser();
    if (!rom_arg.empty()) launch(rom_arg);

    Uint64 freq = SDL_GetPerformanceFrequency(), next = SDL_GetPerformanceCounter(), last_fps = next; int fcount = 0, shot_wait = -1;
    while (running) {
        SDL_Event e; while (SDL_PollEvent(&e)) handle_event(e);
        if (screen == S_REMAP && SDL_GetTicks() > remap_deadline) { screen = S_CONTROLS; sel = saved_sel[S_CONTROLS]; }
        int ww, wh; SDL_GL_GetDrawableSize(win, &ww, &wh);
        bool want_pace = false;

        if (screen == S_GAME && game_loaded && skip_frames > 0) { c_run(); --skip_frames; continue; }
        if (screen == S_GAME && game_loaded) {
            c_run();
            render_scene(ww, wh); present(ww, wh); draw_overlay(ww, wh); ui_flush(ww, wh);
            if (test_frames && test_frames > 0 && --test_frames == 0) {
                if (!open_screen.empty()) {
                    parent_of[S_DISPLAY] = parent_of[S_AUDIO] = parent_of[S_OPTIONS] = parent_of[S_CONTROLS] = S_PAUSE;
                    screen = open_screen == "display" ? S_DISPLAY : open_screen == "audio" ? S_AUDIO : open_screen == "options" ? S_OPTIONS : open_screen == "controls" ? S_CONTROLS : S_PAUSE;
                    sel = 0; shot_wait = 2;
                } else shot_wait = 0;
                if (shot_wait == 0 && !shot.empty()) { save_shot(shot, ww, wh); running = false; }
            }
            want_pace = true;
        } else {
            if (convert_delay > 0 && --convert_delay == 0) { std::string z = pending_convert; pending_convert.clear(); convert_to_cp3(z); scan_browser(); }
            if (game_loaded && screen != S_BROWSER) { if (screen == S_DISPLAY) render_scene(ww, wh); present(ww, wh); } else { glBindFramebuffer(GL_FRAMEBUFFER, 0); glViewport(0, 0, ww, wh); glClearColor(0.03f, 0.04f, 0.11f, 1); glClear(GL_COLOR_BUFFER_BIT); }
            draw_menu(ww, wh); draw_overlay(ww, wh); ui_flush(ww, wh);
            if (shot_wait > 0 && --shot_wait == 0 && !shot.empty()) { save_shot(shot, ww, wh); running = false; }
            else if (!shot.empty() && shot_wait < 0 && !game_loaded && ++test_frames > 3) { save_shot(shot, ww, wh); running = false; }
        }
        SDL_GL_SwapWindow(win);
        if (want_pace && !test_mode) {
            double fps = av.timing.fps > 20 ? av.timing.fps : 60.0;
            next += (Uint64)(freq / fps);
            Uint64 now = SDL_GetPerformanceCounter();
            if (adev && SDL_GetQueuedAudioSize(adev) > (Uint32)(dev_rate * 4 * 0.12)) SDL_ClearQueuedAudio(adev);
            if (now + freq / 500 < next) SDL_Delay((Uint32)((next - now) * 1000 / freq) - 1);
            while (SDL_GetPerformanceCounter() < next) {}
            if (SDL_GetPerformanceCounter() > next + freq / 10) next = SDL_GetPerformanceCounter();
            if (++fcount >= 30) { Uint64 t = SDL_GetPerformanceCounter(); fps_now = fcount * (float)freq / (t - last_fps); last_fps = t; fcount = 0; }
        } else { SDL_Delay(16); next = SDL_GetPerformanceCounter(); last_fps = next; fcount = 0; }
    }
    if (!test_mode) save_config();
    close_game(); c_deinit();
    for (auto *p : pads) SDL_GameControllerClose(p);
    SDL_GL_DeleteContext(glctx); SDL_Quit();
    return 0;
}
